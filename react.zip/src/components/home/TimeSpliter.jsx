
import React from "react";

function TimeSpliter() {
    return (
        <span className="justify-self-end text-white/35 font-poppins text-sm font-light self-end">
            /
        </span>
    );
}

export default TimeSpliter;
